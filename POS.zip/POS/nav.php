<nav class=" fixed-top bg border-bottom" >
  <div class="container-fluid ">
    <div class="row ">
      <div class="col-md-5 p-3 col-sm-3 "><a  href="home.php?status" style="font-size:20px" class="ff3"> Thea's Sweet Creation</a></div>
              <div class="col-md-3 col-sm-1 " id="hide"> </div>
            <div class="col-md-1 col-sm-2 col-xm-1 ff  " ><a href="account.php" class="fff " >ACCOUNT</a></div>
            <div class="col-md-1 col-sm-2 col-xm-1 ff  "><a href="product.php?messege" class="fff " >PRODUCT</a></div>
            <div class="col-md-1 col-sm-2 col-xm-1 ff  "><a href="sales.php?search=&messege=" class="fff " >SALES</a></div>
            <div class="col-md-1 col-sm-2 col-xm-1 ff  "> 
             <a class="btn-outline-danger btn-sm" href="logout.php" onclick="return myFunction()">Logout</a>
            </div>
             <script>
                                    function myFunction() {
                                    var r = confirm("Are you sure to logout?");
                                    if (r == false) {
                                       return false;
                                    } 

                                    }
                                </script>
    </div>
  </div>
</nav>