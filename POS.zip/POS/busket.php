<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}
 
// $url_id =$mysqli->real_escape_string($_POST['p_id']);
// $sql2 = "SELECT count(p_id) AS numID FROM busket WHERE p_id='$url_id'";
// $row2 = mysqli_fetch_assoc($sql2); 
// $result = $row2['numID'];
$url_id =$mysqli->real_escape_string($_GET['id']);
$result2 = mysqli_query($mysqli, "SELECT Count(p_qty) AS value_sum2 FROM busket WHERE p_id= '$url_id'"); 
$row2 = mysqli_fetch_assoc($result2); 
$sum2 = $row2['value_sum2'];

if($sum2 == 0){
   	$qty = 1;
$sql = "INSERT INTO busket (p_name,p_price,p_qty,p_id,p_subtotal) SELECT p_name,p_price,$qty,p_id,p_price FROM products WHERE p_id='$_GET[id]'";


}
else{
$sql = "UPDATE busket SET p_qty = p_qty + 1, p_subtotal = p_subtotal + p_price  WHERE p_id='$_GET[id]'";
}

// $result2 = mysqli_query($mysqli, 'SELECT SUM(p_qty) AS value_sum2 FROM busket'); 
// $row2 = mysqli_fetch_assoc($result2); 
// $sum2 = $row2['value_sum2'];

// if ( $sum2 > 0) {
// 	$qty = 1;

// $sql = "UPDATE busket SET p_qty = p_qty + 1 WHERE p_id='$_POST[p_id]'";

// }else{
// 	$qty = 1;
// $sql = "INSERT INTO busket (p_name,p_price,p_qty,p_id,p_subtotal) SELECT p_name,p_price,$qty,p_id,p_price FROM products WHERE p_id='$_POST[p_id]'";
// }

if(mysqli_query($mysqli,$sql))
$home='location: home.php?status';
        		header($home);

?>