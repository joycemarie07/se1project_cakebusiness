<?php 


session_start();

include "db_conn.php";


if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>

 <!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="cssNav2.css">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<style>


 *{font-family: 'Helvetica', 'Arial', sans-serif;}
    body{
        background-color: #f2f2f2;
    }
    a{
        text-decoration: none;
        color: #fff;
    }
    
    a:hover{
color: #fff;
    }
    .selected1 {
        text-decoration: none;
        color: #dc8ea0;
         font-size: 14px;
    }
    .selected1:hover {
      
        color: #dc8ea0;
    }
    .divbgs{

        background-color: #efcad2;
        color: #dc8ea0;
        font-weight: normal;
        height: 100vh;
        overflow: auto;
    }
    .itemss{
        background-color:#fff ;
        border: 1px solid #fff;
        border-radius: 10px;
        margin: 5px;

    }
 .itemss:hover {
/* box-shadow: 0 0 0 0px #dc8ea0;*/
 transition: .5s;
 background-color: #f8e8ec;
    
}
.centerimg {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 70%;
  border-radius: 5px;
  ;
}
.ablk{
    color: #f8e8ec;
    font-size: 25px;

}
.ablk:hover {
    color: #dc8ea0;
 transition: .5s;
}
@media only screen and (max-width: 1100px) {
    #fadeshow1 {
        display: none;
    }
}
th, td {
    font-family: 'Helvetica', 'Arial', sans-serif;
  padding: 10px;
   font-size: 14px;
}

h6{
    margin: 0px;
    padding: 0px;
}
table{
    width: 100%;
}
.ht{
    height: 650px;
    overflow: scroll;
}
</style>
</head>
<body>

         <!--NAV BAR-->
<?php 
include "nav.php";
?>  

         <!--CONTENTS-->
         <div class="container-fluid"> 
            
            <div class="row ">
                    <!--Left side-->
                <div class="col-lg-2 col-md-1 col-sm-1 divbgs"> <br><br><br> 
                        <div class="row itemss p-2 selected1">
                           <h6><a href="account.php" class="selected1" ><i class="fas fa-user-alt" ></i> <span id="fadeshow1">My Account</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6><a href="addAcount.php?status=" class="selected1"><i class="fas fa-user-plus"></i> <span id="fadeshow1">Add Account</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6><a href="acclist.php" class="selected1"><i class="fas fa-users"></i> <span id="fadeshow1">Employee List</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6> <a href="home.php?status" class="selected1"><i class="fa fa-arrow-circle-left"></i> <span id="fadeshow1">Back</span></a></h6>
                        </div>
                        
                  </div>
                    <!--Right side-->
                <div class="col-10 ht">

                    <br><br><br>
                    <div class="row p-2  border-bottom">
                        <h2 style="color:#dc8ea0;font-weight:bold"><i class="fas fa-users"></i> Employee List</h2>
                    </div>


                    <div class="row p-4">
                        <div class="col-12 rounded-top" style="background-color:#dc8ea0;height: 40px;" >
                                    <p style="font-size:15px;color:#fff;margin: 10px  ;">Account List</p>
                              </div>

                        <div class="col-12" style="background-color:#fff">
                         <?php
                                $mysqli = new mysqli("localhost", "root", "", "test_db");
                                $sql = "SELECT * FROM users WHERE id != '$_SESSION[id]'";

                                if($result = $mysqli->query($sql)){


                                        if($result->num_rows > 0){
                                            echo "<table>";
                                            echo "<tr>";
                                                echo "<th>Username</th>";
                                                echo "<th >Name</th>";
                                                
                                                echo "<th>Address</th>";
                                                echo "<th>Email</th>";
                                                echo "<th>Contact</th>";
                                                echo "<th>Action</th>";
                                            echo "</tr>";
                                             
                                            while($rowss = $result->fetch_array())
                                            {
                                            echo "<tr>";

                                                echo "<td>" . $rowss['user_name'] . "</td>";
                                               
                                                echo "<td >" . $rowss['fname'] ." ". $rowss['mname'] . " ". $rowss['lname'] . "</td>";
                                               
                                                echo "<td >" . $rowss['address'] . "</td>";
                                                echo "<td>" . $rowss['email'] . "</td>";
                                                echo "<td >" . $rowss['contact'] . "</td>";

                                                // echo "<td  ><a href='#'style='font-size:20px;color:#c4727c'><i class='fa fa-trash-o hrd'></i></a></td>";
                                                echo "<td>
                                                        <a href='function/edituser.php?id=". $rowss['id'] . " ' class='btn btn-success btn-sm rounded-0'><i class='fas fa-edit  '></i></a>
                                                        <a href='function/deleteuser.php?id=". $rowss['id'] . "' class='btn btn-danger btn-sm rounded-0' onclick='return myFunction()'><i class='fa fa-trash');'></i></a>
                                                      </td>";
                                            echo "</tr>";
                                            
                                            }
                                            echo "</table>";
                                            
                                        }
                                        
                                else
                                {
                                    echo "No selected item/s yet.";
                                }

                                }

                            ?>
                        </div>

                    </div>

                        <script>
                            function myFunction() {
                            var r = confirm("OK to delete?");
                            if (r == false) {
                               return false;
                            } 

                            }
                    </script>
                  </div>
            </div>
        </div>
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>