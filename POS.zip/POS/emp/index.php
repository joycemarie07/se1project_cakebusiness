<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	

<style type="text/css">
body {
	background-color: #828181;
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	flex-direction: column;
}

*{
	 font-family: Verdana, sans-serif;
	box-sizing: border-box;
	font-stretch: ultra-expanded;

}

form {
	width: 350px;
	border: 1px solid #f2f2f2;
	padding: 30px;
	background: #fff;
	box-shadow: 0px 0px 20px black;
	background-color:#fff;
}

h2 {
	
	font-size: 20px;
	width: 100%;
	font-weight: 100;
	color: #f19dc4;
	text-align: center;
}

input {
	outline: none;
	 border: 1px solid #ccc;
	width: 100%;	
	padding: 10px ;
	margin: 0px auto 20px auto;

}
input:focus {
	 outline: none;
  border: 1px solid #e5448d;
  box-shadow: 0px 0px 4px #e5448d;
}
label {
	color: #888;
	font-size: 18px;
	padding: 10px;
}

button {
	width: 100%;	
	background: #eb71a8;
	padding: 10px 15px;
	color: #fff;

	margin-right: 10px;
	border: none;
	cursor: pointer;
}
button:hover{
	background: #e5448c;
	transition: .5s;
}
.error {
   background: #ffcccb;
   color: #CD5C5C;
   padding: 15px;
   width: 100%;
   font-size: 14px;
   margin: 20px auto;
}



	</style>
</head>
<body>
	
     <form action="login.php" method="post">
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error" id="alert"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<script type="text/javascript">
         setTimeout(function(){
             document.getElementById("alert").style.display ="none";
         },2000);
		</script>
     	<h2>POS Portal | Login</h2>
     	
     	<br>
     	<center><img src="images/loginIcon.png" width="120px" height="120px" style=""></center>
     	<br>
     	
	
     	<input type="text" name="uname" placeholder="User Name"><br>
		
     	<input type="password" name="password" placeholder="Password"><br>
     
      <button type="submit">Login</button>
      <br><br>
      <p style="color:#ccc;font-size: 12px;text-align: center;">Cashier and Admin login Form.</p>

     </form>

</body>
</html>