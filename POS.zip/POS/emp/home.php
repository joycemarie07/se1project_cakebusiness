<?php 


session_start();

include "db_conn.php";


if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="cssNav2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@200&display=swap" rel="stylesheet">

<style>

    *{font-family: 'Helvetica', 'Arial', sans-serif;}
body{
    background-color:#f2f2f2;
}

table{width: 100%;}
td{font-family: "Lucida Console", "Courier New", monospace;}
.divbg{background-color: #bfbfbf;color: #fff;font-weight: normal;}


.hrd:hover{color: red}

    a{
        text-decoration: none;
        color: #f2f2f2;
    }
    a:hover{
color: #fff;
    }
    .ht1{height: 280px;overflow: auto;}
    .ht2{height: 60px;}
    table{width: 100%;}
    .hhf{height: 90vh;
        overflow: auto;}
    .hhf::-webkit-scrollbar {
  display: none;
}
    .hhf2{
        border-radius: 5px ;
        height: 530px;
        overflow: hidden;

    }

    .img-item{
        color: black;
        }
    .img-item:hover{
        color:#333;
        }
    .price{
        color: red;
    }
    .fade1{

        background-color: #fff;
        height: 250px;
        border: 2px solid #e8b5c1;
        box-shadow: 2px 2px 5px #e8b5c1;
        border-radius: 10px;
    }
    .fade1:hover{
    
         opacity: 90%;
  transition: opacity 1s;
    }
    .green{background-color: #fff; color:#dc8ea0;border: 2px solid #dc8ea0; }
    .green:hover{background-color: #f2f2f2;transition: .5s;}
</style>
</head>
<body>

         <!--NAV BAR-->
<?php 
include "nav.php";
?>
<div class="ht2"></div>
   <div class="container-fluid">

         <!--CONTENTS-->
         <?php
               
               $sql = "SELECT * FROM products";
               $all_product= $conn->query($sql);

               
          ?>
         <div class="container-fluid ">
               <div class="row">
                         <!--PRODUCTS-->
                    <div class="col-md-7 hhf ">

                         <div class="row">  

                         
                         <?php 
                         while ($row = mysqli_fetch_assoc($all_product)) { 
                         ?>
                        <div class="col-md-6 col-lg-4 mt-2 ">
                              <div class="fade1 " style="width: 100%;">
                                 <a href="busket.php?id=<?php echo $row['p_id'] ?>" class="img-item ">
                                <img src="<?php echo $row["p_image"]; ?>" class="card-img-top " width="95%" height="150" style="text-align: center;">
                                <div class="card-body d-grid">
                                   
                                  <h6 class="card-title"><?php echo $row["p_name"] ?></h6>

                                  <h6 class="card-text price">₱ <?php echo $row["p_price"] ?>.00</h6>
                                  </a>
                                </div>
                              </div> 
                        </div>
                        <?php 
                         }
                         ?> 
                         </div>
                    </div>
                          <!--Busket Calculation-->
                        
                    <div class="col-md-5 hhf2 rounded-top"  style="background-color:#e5acb9; ">

                        <div class="" style=" height: 35px; ">

                            <p class="p-3" style="color:#fff;font-weight: normal;font-size: 20px;">Basket</p>
                        </div>

                         <div class="row ht1 ">    
                            
                         
                             <div class="col-12 mt-4" style="background-color:#fff;">

                                <br>
                                 <?php
                                $mysqli = new mysqli("localhost", "root", "", "test_db");
                                $sql = "SELECT * FROM busket";

                                if($result = $mysqli->query($sql)){


                                        if($result->num_rows > 0){
                                            echo "<table>";
                                            echo "<tr>";
                                                echo "<th></th>";
                                                echo "<th>Qty</th>";
                                                echo "<th >Product</th>";
                                                echo "<th></th>";
                                                echo "<th>Price</th>";
                                                echo "<th></th>";
                                                echo "<th>Subtotal</th>";
                                                echo "<th></th>";
                                            echo "</tr>";
                                             
                                            while($rowss = $result->fetch_array())
                                            {
                                            echo "<tr>";
                                                echo "<td> <form action='function/minusqty.php' method='post'><input type=hidden name=p_id value='" . $rowss['p_id'] . "'><input onclick='myFunctions()' type=submit value='-'  style='font-size:10px;color:#c4727c'></form></td>";
                                                

                                            
                                                echo "<td> x" . $rowss['p_qty'] . "</td>";

                                                echo "<td colspan='2'>" . $rowss['p_name'] . "</td>";
                                               
                                                echo "<td colspan='2'>" . $rowss['p_price'] . "</td>";
                                               
                                                echo "<td colspan='2'>" . $rowss['p_subtotal'] . "</td>";

                                                // echo "<td  ><a href='#'style='font-size:20px;color:#c4727c'><i class='fa fa-trash-o hrd'></i></a></td>";
                                                echo "<td><form action='function/deletebasket.php' method='post'><input type=hidden name=p_id value='" . $rowss['p_id'] . "'><input onclick='myFunctions()' type=submit value='X'  style='font-size:15px;color:#c4727c'></form></td>";
                                            echo "</tr>";
                                            
                                            }
                                            echo "</table>";
                                            
                                        }
                                        
                                else
                                {
                                    echo "No selected item/s yet.";

                                }

                                }

                            ?>
                             </div>
                            </div>
                            
                            <?php 
                                $mysqli = new mysqli("localhost", "root", "", "test_db");
                               
                                $result = mysqli_query($mysqli, 'SELECT SUM(p_subtotal) AS value_sum FROM busket'); 
                                $row = mysqli_fetch_assoc($result); 
                                $sum = $row['value_sum'];

                                $result2 = mysqli_query($mysqli, 'SELECT SUM(p_qty) AS value_sum2 FROM busket'); 
                                $row2 = mysqli_fetch_assoc($result2); 
                                $sum2 = $row2['value_sum2'];

                            ?>
                                <div class="row border-top border-bottom pt-2">
                                    <div class="col-5"><h5 style="color:#fff;">Total Quantity:<span ><?php echo" $sum2" ?></span>  </h5></div>
                                    <div class="col-7"><h5 style="color:#fff;">Total Price: <span >₱<?php echo" $sum" ?>.00</span></h5></div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-12 p-2">
                                                                           
                                        <table>
                                                <tr>
                                                    <td><h5 style="color:#fff;">Payment/Cash: </h5> </td>
                                                    <td>
                                                        <?php 
                                                             echo "<form action=function/pay.php method=post>";
                                                        ?>
                                                            <input class="form-control"type="number" id="replyNumber" name="cash" data-bind="value:replyNumber" style="font-size: 18px" />
                                                    </td>
                                                </tr>                    
                                        </table>  

                                    </div>

                                    <div class="col-7">
                                        
                                         <?php 
                                        
                                            
                                            echo "<input class='p-2 w-100 green' type='submit' value='Pay' name='change' style='font-weight: bold; '>";
                                            echo "</form>";
                                        ?>
                                    </div>
                                    
                                    <div class="col-5">            
                                        <?php 
                                        
                                             echo "<form action=function/removeall.php method=post>";
                                            echo "<input class='p-2 w-100' type='submit' value='Remove all'  style='color:red;border: 2px solid #dc8ea0;'>";
                                            echo "</form>";
                                        ?>
                                    </div>

                                </div>

                                    <!-- ALETS MESSEGES -->
                                    <script type="text/javascript">
                                    setTimeout(function(){
                                        document.getElementById("alert").style.display ="none";
                                    },3000);
                                    </script>
                                <div class="ht2 p-2">
                                     <?php if( $_GET['status'] == 'success'):
                                            echo '<div class="alert alert-success" role="alert" id="alert">
                                                        Purchase Complete!
                                                        </div>';
                                        endif; ?>

                                        <?php if( $_GET['status'] == 'failed'):
                                            echo '<div class="alert alert-danger" role="alert"id="alert">
                                                       Payment Insufficient!
                                                        </div>';
                                        endif; ?>
                                        <?php if( $_GET['status'] == 'empty'):
                                            echo '<div class="alert alert-danger" role="alert"id="alert">
                                                        Cash amount is required.
                                                        </div>';
                                        endif; ?>
                                        <?php if( $_GET['status'] == 'emptybskt'):
                                            echo '<div class="alert alert-danger" role="alert"id="alert">
                                                       Selected Item/s are required.

                                                        </div>';
                                        endif; ?>
                                </div>
                    </div>

              </div>
         </div>
          
   </div>
</body> 

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>