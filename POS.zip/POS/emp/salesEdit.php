<?php 
session_start();
include "db_conn.php";
if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>

<?php 
// UPDATE PROFILE
if (isset($_POST['btnUpdate'])) {
    $id = $_POST['id'];
    $qty = $_POST['qty'];
    $price = $_POST['price'];
    $cash = $_POST['cash'];
    $change = $_POST['change'];
    $odate = $_POST['odate'];
 
   
   mysqli_query($conn,"UPDATE sales SET total_qty='$qty',total_price='$price',pchange='$change',odate='$odate'  WHERE salesId='$id'");
    header('location: sales.php?search=&messege=');
}
    
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

<style type="text/css">
     body{
    background-color:#f2f2f2;
}
</style>
</head>
<body>

	
			 <!--MODAL SECTION-->

        <div class=" "  >
                  <div class="modal-dialog ">
                    <div class="modal-content">
                        <form action="#" method="post">
                      <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Product Details</h1>
                        <a href="sales.php?search=&messege=" class="btn-close"></a>
                      </div>
                      <div class="modal-body ">
                        <div class="form-group">
                            <?php
                                $mysqli = new mysqli("localhost", "root", "", "test_db");
                                $sql = "SELECT * FROM sales  where salesId='$_GET[id]' ";
                                if($result = $mysqli->query($sql)){
                                    if($result->num_rows > 0){
                                        while($rowss = $result->fetch_array())
                                            {
                                                ?>
                            <input type="hidden" name="id"  class="form-control" value="<?php echo $rowss['salesId'] ?>" >                   
                            <label>Total Quantity: </label>
                            <input type="text" name="qty" class="form-control" value="<?php echo $rowss['total_qty'] ?>" >
                            <label>Total Price: </label>
                            <input type="text" name="price" class="form-control" value="<?php echo $rowss['total_price'] ?>" >
                            <label>Cash/Payment: </label>
                            <input type="text" name="cash" class="form-control" value="<?php echo $rowss['cash'] ?>" >
                            <label>Change</label>
                            <input type="text" name="change" class="form-control" value="<?php echo $rowss['pchange'] ?>" >
                            <label>Date | Time: </label>
                            <input type="text" name="odate" class="form-control" value="<?php echo $rowss['odate'] ?>" >
                            
                           
                           
                                <?php   }
                                        }   
                                else
                                {
                                    echo "No Records.";
                                }
                                }
                                    ?>
                        </div>
                            
                      </div>
                      <div class="modal-footer">
                         <a href="sales.php?search=&messege="class="btn btn-secondary" >Close</a>
                        <button type="submit" class="btn btn-primary" name="btnUpdate">Save changes</button>
                      </div>
                        </form>
                    </div>
                  </div>
                </div>
	
</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}

 ?>