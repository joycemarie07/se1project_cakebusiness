<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}
$id = (int)$_GET['p_id'];
$sql = "DELETE FROM products WHERE p_id='$id'";

if(mysqli_query($mysqli,$sql))
$stdbtn='location: ../product.php?messege';
        		header($stdbtn);
?>