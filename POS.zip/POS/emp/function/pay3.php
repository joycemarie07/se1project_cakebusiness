<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}
	$idf = 1;

	// $sql = "UPDATE salesorders SET sales_id = sales.salesId FROM(SELECT salesId,idf FROM sales) AS sales WHERE sales.idf =  salesorders.idf ";
				
	
	$sql = "UPDATE
		    salesorders SO,
		    sales SS
			SET
			    SO.sales_id = SS.salesId
			WHERE
			    SO.idf = SS.idf AND  SS.idf='$idf'";


			
if(mysqli_query($mysqli,$sql))
header("location: pay4.php");

?>