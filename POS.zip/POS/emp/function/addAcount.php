<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}

function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}
	
$vfname = validate($_POST['fname']);
$vmname = validate($_POST['mname']);
$vlname = validate($_POST['lname']);
$vaddress = validate($_POST['address']);
$vcontact = validate($_POST['contact']);
$vemail = validate($_POST['email']);
$vusername = validate($_POST['username']);
$vpassword = validate($_POST['password']);

if (empty($vfname)) {
		header("location: ../addAcount.php?status=failed");
	    exit();
	}else if(empty($vmname)){
        header("location: ../addAcount.php?status=failed");
	    exit();
	}else if(empty($vlname)){
        header("location: ../addAcount.php?status=failed");
	    exit();
	}
	else if(empty($vaddress)){
        header("location: ../addAcount.php?status=failed");
	    exit();
	}
	else if(empty($vcontact)){
        header("location: ../addAcount.php?status=failed");
	    exit();
	}
	else if(empty($vemail)){
        header("location: ../addAcount.php?status=failed");
	    exit();
	}else if(empty($vusername)){
        header("location: ../addAcount.php?status=failed");
	    exit();
	}
	else if(empty($vpassword)){
        header("location: ../addAcount.php?status=failed");
	    exit();
	}else{


$fname = $mysqli->real_escape_string($_POST['fname']);
$mname = $mysqli->real_escape_string($_POST['mname']);
$lname = $mysqli->real_escape_string($_POST['lname']);

$address = $mysqli->real_escape_string($_POST['address']);
$contact = $mysqli->real_escape_string($_POST['contact']);
$email = $mysqli->real_escape_string($_POST['email']);
$username = $mysqli->real_escape_string($_POST['username']);
$password = $mysqli->real_escape_string($_POST['password']);

$sql = "INSERT INTO users (fname, mname, lname, address, contact, email,user_name,password)
					  VALUES ('$fname','$mname','$lname','$address','$contact','$email','$username','$password')";


if(mysqli_query($mysqli,$sql))
$home='location: ../addAcount.php?status=success';
        		header($home);

}
?>