<?php 


session_start();




if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/css.css">


<style >
    @media print{
        .noprint, .noprint *{
            display: none; !important;
        }
    }
    body{
        width: 500px;
    background-color:#f2f2f2;

}
     *{font-family: 'Helvetica', 'Arial', sans-serif;}



table {
    background-color: #fff;
    width: 100%;
    border-collapse: collapse;
    letter-spacing: 1px;
    font-family: sans-serif;
    font-size: .8rem;

}
th, td {
    font-family: 'Helvetica', 'Arial', sans-serif;
  padding: 10px;
  font-size: 12px;


}
.css{
    
    margin: auto;
    background-color: #fff;
    padding: 2px;
}
tfoot {
    
    color: #fff;
}
.h3{
    font-family: "Times New Roman", Times, serif;
    font-weight: bold;
}
.p1{
    margin:0px;
    padding: 0px;
    font-size: 12px;
}
</style>
</head>
<!-- onload="print()" -->
<body onload="print()">

<div class="css"><br>
    <center>
        <h3 class="h3">Thea's Sweet Creation.</h3>
    </center>
    <br>
    <div class="container">
    <p class="p1">Telephone: 0123-456-789</p>
    <p class="p1">Email: support@yourwebsite.com</p>
    </div>
<?php
                                
                            
        $mysqli = new mysqli("localhost", "root", "", "test_db");
        $sql = "SELECT * FROM salesorders WHERE sales_Id = (SELECT MAX(sales_Id) FROM salesorders)";
            if($result = $mysqli->query($sql)){
                    if($result->num_rows > 0){   

         echo "<table class=' ' style='background-color:#fff'>";
          echo "<thead>";
            echo "<tr>";

              echo "<th scope='col'>#</th>";
              echo "<th scope='col'>Name</th>";
              echo "<th scope='col'>Price</th>";
              echo "<th scope='col'>Subtotal</th>";
            
            echo "</tr>";
          echo "</thead>";

                        while($rowss = $result->fetch_array())
                        {
          echo "<tbody>";
            echo "<tr>";
             echo " <td>" . $rowss['pqty'] . "</td>";
              echo "<td>" . $rowss['pname'] . "</td>";
              echo "<td>" . $rowss['pprice'] . "</td>";
              echo "<td>" . $rowss['subtotal'] . "</td>";
        
              
            echo "</tr>";
          echo "</tbody>";
           }
            echo "<tfoot>";

            echo"<tr>";

            echo"</td>";
            echo"<td colspan='2'>
                <h2 style='color:black'>TOTAL</h2>
            </td>";
            echo"<td colspan='2'>";
            $result = mysqli_query($mysqli, "SELECT SUM(total_price) AS value_sum FROM sales WHERE salesId = (SELECT MAX(salesId) FROM sales) "); 
                                $row = mysqli_fetch_assoc($result); 
                                $sum = $row['value_sum'];
            
            echo "<h2 style='color:black;text-align:center'> ". $sum.".00</h2>";

            echo"</td>";
            echo"</tr>";

            echo"<tr>";
            echo"<td colspan='2'>";
                                echo "<h6 style='color:black;'>Cash</h6>";                 
                                echo "<h6 style='color:black;'>Change</h6>";            echo"</td>";
              echo"<td colspan='2'>";
                $result = mysqli_query($mysqli, "SELECT cash,pchange  FROM sales WHERE salesId = (SELECT MAX(salesId) FROM sales)"); 
                                $row = mysqli_fetch_assoc($result); 
                                $pchange = $row['pchange'];
                                $cash = $row['cash'];
                                echo "<h6 style='color:black;text-align:center'> ". $cash.".00</h6>";                 
                                echo "<h6 style='color:black;text-align:center'> ". $pchange.".00</h6>";

            echo"</td>";
              echo"</tr>";
               ?>
            <td colspan="4" style="text-align:center;color: black;font-weight: bold;">
                ****BASTA MAY SULAT DITO****
            </td>
           <?php
           echo "<tfoot>";

        echo "</table>";       

          }
                    
            else
            {
                echo "No Current Items.";
            }

            }

        ?>
</div>
 

<div class="container">
    <button type="" class="btn btn-secondary noprint" style="width: 100%;color:#fff" onclick="window.location.replace('../home.php?status=success');">CANCEL PRINTING</button>
</div>
</body> 

</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>