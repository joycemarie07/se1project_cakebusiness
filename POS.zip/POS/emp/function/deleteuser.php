<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}
$id = (int)$_GET['id'];
$sql = "DELETE FROM users WHERE id='$id'";


if(mysqli_query($mysqli,$sql))
$stdbtn='location: ../acclist.php';
        		header($stdbtn);
?>