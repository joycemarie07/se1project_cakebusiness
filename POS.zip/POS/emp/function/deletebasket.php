<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}

$sql = "DELETE FROM busket WHERE p_id='$_POST[p_id]'";

if(mysqli_query($mysqli,$sql))
$stdbtn='location: ../home.php?status';
        		header($stdbtn);
?>