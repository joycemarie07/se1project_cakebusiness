<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}
$id = (int)$_GET['salesId'];
$sql = "DELETE FROM sales WHERE salesId='$id'";

if(mysqli_query($mysqli,$sql))
$stdbtn='location: ../sales.php?search=&messege=';
        		header($stdbtn);
?>