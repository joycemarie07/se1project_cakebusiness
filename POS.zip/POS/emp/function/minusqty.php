<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}

$url_id =$mysqli->real_escape_string($_POST['p_id']);
$result2 = mysqli_query($mysqli, "SELECT Sum(p_qty) AS value_sum2 FROM busket WHERE p_id= '$url_id'"); 
$row2 = mysqli_fetch_assoc($result2); 
$sum2 = $row2['value_sum2'];

if($sum2 == 1){
$sql = "DELETE FROM busket WHERE p_id='$_POST[p_id]'";

}else{
	$sql = "UPDATE busket SET p_qty = p_qty - 1, p_subtotal = p_subtotal - p_price  WHERE p_id='$_POST[p_id]'";
}

if(mysqli_query($mysqli,$sql))
$home='location: ../home.php?status';
        		header($home);

?>