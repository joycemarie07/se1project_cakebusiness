<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}

function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

$cash = validate($_POST['cash']);

$result2 = mysqli_query($mysqli, "SELECT Sum(p_subtotal) AS value_sum2 FROM busket "); 
$row2 = mysqli_fetch_assoc($result2); 
$sum2 = $row2['value_sum2'];



$s2 = (int)$sum2;
$c1 = (int)$cash;
$pchange = $c1 - $s2;
$name = "Admin";

$result1 = mysqli_query($mysqli, "SELECT b_id FROM busket "); 
$row1 = mysqli_fetch_assoc($result1); 
$busket = $row1['b_id'];

if (empty($busket)) {
		header("location: ../home.php?status=emptybskt");
	    exit();
	}
if (empty($cash)) {
		header("location: ../home.php?status=empty");
	    exit();
	}
else if($sum2 > $cash){
header("location: ../home.php?status=failed");
	    exit();
}

	$idf = 1;

	$sql = "INSERT INTO sales (total_qty, total_price, cash, pchange, odate, cashier, idf)
			SELECT Sum(p_qty),Sum(p_subtotal),'$cash','$pchange',now(),'$name','$idf'
				FROM busket ";
				


if(mysqli_query($mysqli,$sql))
header("location: pay2.php");




?>