<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}
	$idf = 2;

	// $sql = "UPDATE salesorders SET sales_id = sales.salesId FROM(SELECT salesId,idf FROM sales) AS sales WHERE sales.idf =  salesorders.idf ";
				
	
$sql = "UPDATE sales SET idf='$idf' WHERE idf=1";
			
if(mysqli_query($mysqli,$sql))
header("location: pay6.php");

?>