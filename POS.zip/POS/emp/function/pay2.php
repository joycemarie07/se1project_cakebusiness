<?php
$mysqli = new mysqli("localhost", "root", "", "test_db");
if($mysqli === false) {
	die("ERROR: Could not connect. " . $mysqli->connect_error);
}
	$idf = 1;

	$sql = "INSERT INTO salesorders (pname,pprice,pqty, idf)
			SELECT p_name,p_price,p_qty,'$idf'
				FROM busket ";
			
if(mysqli_query($mysqli,$sql))
header("location: pay3.php");

?>