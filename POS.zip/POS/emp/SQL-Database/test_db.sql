-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2022 at 02:44 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `busket`
--

CREATE TABLE `busket` (
  `b_id` int(11) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `p_price` int(50) NOT NULL,
  `p_qty` int(50) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_subtotal` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `p_price` int(50) NOT NULL,
  `p_details` varchar(500) NOT NULL,
  `p_image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_name`, `p_price`, `p_details`, `p_image`) VALUES
(31, 'Captain America Cupcake', 255, 'Product Size: Small 6 inches | 12 Servings Cake Flavor: Chocolate', 'images/cap7.jpg'),
(32, 'Butterfly Themed Cake', 1500, 'Product Size: Small 6 inches | 12 Servings Cake Flavor: Chocolate', 'images/Butterfly.jpg'),
(33, 'Boss Baby Cake', 999, 'Product Size: Small 6 inches | 12 Servings Cake Flavor: Chocolate', 'images/Boss.jpg'),
(34, ' Spiderman Birthday Cake', 200, 'Product Size: Small 6 inches | 12 Servings Cake Flavor: Chocolate', 'images/spidy.jpg'),
(35, ' Tiktok Themed Cake', 500, 'Product Size: Small 6 inches | 12 Servings Cake Flavor: Chocolate', 'images/tiktok.jpg'),
(36, 'Jack Daniels Themed Cake', 1399, 'Product Size: Small 6 inches | 12 Servings Cake Flavor: Chocolate', 'images/emp.png');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `salesId` int(11) NOT NULL,
  `total_qty` int(50) NOT NULL,
  `total_price` int(50) NOT NULL,
  `cash` int(50) NOT NULL,
  `pchange` int(50) NOT NULL,
  `odate` varchar(50) NOT NULL,
  `cashier` varchar(50) NOT NULL,
  `idf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`salesId`, `total_qty`, `total_price`, `cash`, `pchange`, `odate`, `cashier`, `idf`) VALUES
(56, 4, 1155, 1500, 345, '2022-10-21 00:30:38', 'Admin', 2),
(57, 2, 1499, 2000, 501, '2022-11-21 10:27:42', 'Admin', 2),
(58, 10, 8796, 10000, 1204, '2022-11-21 12:35:59', 'Admin', 2),
(59, 4, 2753, 3000, 247, '2022-11-21 15:16:30', 'Admin', 2);

-- --------------------------------------------------------

--
-- Table structure for table `salesorders`
--

CREATE TABLE `salesorders` (
  `so_Id` int(11) NOT NULL,
  `sales_Id` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `pprice` int(11) NOT NULL,
  `pqty` int(11) NOT NULL,
  `idf` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salesorders`
--

INSERT INTO `salesorders` (`so_Id`, `sales_Id`, `pname`, `pprice`, `pqty`, `idf`, `subtotal`) VALUES
(135, 56, ' Tiktok Themed Cake', 500, 1, 2, 500),
(136, 56, ' Spiderman Birthday Cake', 200, 2, 2, 400),
(137, 56, 'Captain America Cupcake', 255, 1, 2, 255),
(138, 57, 'Boss Baby Cake', 999, 1, 2, 999),
(139, 57, ' Tiktok Themed Cake', 500, 1, 2, 500),
(141, 58, 'Boss Baby Cake', 999, 2, 2, 1998),
(142, 58, 'Butterfly Themed Cake', 1500, 1, 2, 1500),
(143, 58, ' Tiktok Themed Cake', 500, 5, 2, 2500),
(144, 58, 'Jack Daniels Themed Cake', 1399, 2, 2, 2798),
(148, 59, 'Captain America Cupcake', 255, 1, 2, 255),
(149, 59, 'Boss Baby Cake', 999, 2, 2, 1998),
(150, 59, ' Tiktok Themed Cake', 500, 1, 2, 500);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `fname`, `mname`, `lname`, `address`, `email`, `contact`) VALUES
(1, 'admin', '123', 'Elias', 'Gitna', 'Cruz', 'Quezon City', 'Cruz@email.com', 911111111),
(12, 'asd', 'asd', 'Denmark', 'Ocfemia', 'Cambe', 'Quezon City', 'denmark.cambe10@gmail.com', 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `busket`
--
ALTER TABLE `busket`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`salesId`);

--
-- Indexes for table `salesorders`
--
ALTER TABLE `salesorders`
  ADD PRIMARY KEY (`so_Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `busket`
--
ALTER TABLE `busket`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=591;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `salesId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `salesorders`
--
ALTER TABLE `salesorders`
  MODIFY `so_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
