<?php 


session_start();

include "db_conn.php";


if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/css.css">


<style >
    @media print{
        .noprint, .noprint *{
            display: none; !important;
        }
    }
    body{
        width: 500px;
    background-color:#f2f2f2;

}
     *{font-family: 'Helvetica', 'Arial', sans-serif;}



table {
    background-color: #fff;
    width: 100%;
    border-collapse: collapse;
    border: 2px solid rgb(200, 200, 200);
    letter-spacing: 1px;
    font-family: sans-serif;
    font-size: .8rem;

}
th, td {
    font-family: 'Helvetica', 'Arial', sans-serif;
  padding: 10px;
  font-size: 12px;
border: 1px solid #ccc;

}
.css{
    
    margin: auto;
    background-color: #fff;
    padding: 2px;
}
tfoot {
    
    color: #fff;
}

</style>
</head>
<body onload="print()">

<div class="css"><br>
    <center>
        <h4>Sales Report</h4>
    </center>
<?php
                                
                              
        $mysqli = new mysqli("localhost", "root", "", "test_db");
        $sql = "SELECT * FROM sales";

               
             
            if($result = $mysqli->query($sql)){


                    if($result->num_rows > 0){   

         echo "<table class='table ' style='background-color:#fff'>";
          echo "<thead>";
            echo "<tr>";
              echo "<th scope='col'>#</th>";
              echo "<th scope='col'>Quantity</th>";
              echo "<th scope='col'>Total Price</th>";
              echo "<th scope='col'>Cash</th>";
              echo "<th scope='col'>Change</th>";
              echo "<th scope='col'>Date | Time</th>";
            echo "</tr>";
          echo "</thead>";

                        while($rowss = $result->fetch_array())
                        {
          echo "<tbody>";
            echo "<tr>";
              echo "<th scope='row'>" . $rowss['salesId'] . "</th>";
             echo " <td>" . $rowss['total_qty'] . "</td>";
              echo "<td>" . $rowss['total_price'] . "</td>";
              echo "<td>" . $rowss['cash'] . "</td>";
              echo "<td>" . $rowss['pchange'] . "</td>";
              echo "<td>" . $rowss['odate'] . "</td>";
              
            echo "</tr>";
          echo "</tbody>";
           }
            echo "<tfoot>";
            echo"<tr>";
            echo"<td colspan='4'>";
            $result = mysqli_query($mysqli, 'SELECT SUM(total_price) AS value_sum FROM sales'); 
                                $row = mysqli_fetch_assoc($result); 
                                $sum = $row['value_sum'];

            echo "<div class='col-7'><p style='color:black;text-align:center'>Total Amount: ₱ ". $sum.".00</p></div>";
            echo"<td>";
            echo"<tr>";
           echo "<tfoot>";
        echo "</table>";

       

          }
                    
            else
            {
                echo "No Current Items.";
            }

            }

        ?>
</div>
 

<div class="container">
    <button type="" class="btn btn-secondary noprint" style="width: 100%;color:#fff" onclick="window.location.replace('sales.php?search=&messege=');">CANCEL PRINTING</button>
</div>
</body> 

</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>