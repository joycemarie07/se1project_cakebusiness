<?php 


session_start();

include "db_conn.php";


if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="cssNav2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<style>
    body{
    background-color:#f2f2f2;
}
     *{font-family: 'Helvetica', 'Arial', sans-serif;}
    a{
        text-decoration: none;
        color: #f2f2f2;
    }
    a:hover{
color: #fff;
    }
    .ht1{height: 400px;overflow: auto;}
    .ht2{height: 60px;}
    table{width: 100%;
    }
    .divbgs{
        background-color: #3b5073;
        color: #fff;
        font-weight: normal;
        height: 100vh;
        overflow: auto;
    }
       .ht{
        height: 100vh;
        overflow: scroll;
    }
 .itemss:hover {
 box-shadow: 0 0 0 1px #d0d0d0;
    
}
.centerimg {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 70%;
  border-radius: 5px;
  ;
}
.ablk{
    color: black;
    font-size: 25px;

}

th, td {
    font-family: 'Helvetica', 'Arial', sans-serif;
  padding: 10px;
  font-size: 14px;

}

.hhf{height: 95vh;
        overflow: auto;}
</style>
</head>
<body>

         <!--NAV BAR-->
<?php 
include "nav.php";
?>

<!--CONTENTS-->
         <div class="container-fluid"> 
            
            <div class="row ">
                    <!--Left side-->
               <!--  <div class="col-lg-2 col-md-1 col-sm-1 divbgs"> <br><br><br> 
                        <div class="row itemss p-2">
                           <h6> <a href="product.php?messege"><i class="fa fa-list" ></i> <span id="fadeshow1">Product list</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6 ><a href="productAdd.php"><i class="fa fa-birthday-cake"></i> <span id="fadeshow1">Add Product</span></a></h6>
                        </div>
                       
                        <div class="row itemss p-3">
                           <h6> <a href="home.php?status"><i class="fa fa-arrow-circle-left"></i> <span id="fadeshow1">Back</span></a></h6>
                        </div>
                        
                  </div> -->
                    <!--Right side-->
                <div class="col-12">
                <br> 
                <br> 
                <br> 
                <div class="row p-2  border-bottom">
                        <h2 style="color:#dc8ea0;font-weight:bold"><i class="fa fa-list"></i> Add new Item</h2>
                    </div>

                    <div class="row p-4">
                        
                         <div class="col-12 rounded-top" style="background-color:#dc8ea0;height: 40px;" >
                                    <p style="font-size:15px;color:#fff;margin: 10px  ;">Product Form</p>
                              </div>
                        
                        <div class="col-7  p-2" style="background-color: #fff">
                            <form action="" method="post" enctype="multipart/form-data">
                            <label for="inputPassword5" class="form-label">Name</label>
                            <input type="text" name="names" class="form-control" required>
                            <div id="passwordHelpBlock" class="form-text">
                             Enter the item Name. 
                            </div>
                            <br>
                            <label for="inputPassword5" class="form-label">Details</label>
                            <input type="text" name="details" class="form-control" required>
                            <div id="passwordHelpBlock" class="form-text">
                              Your Details must contain the item's descriptions and its ingredient. 
                            </div>
                        </div>
                        <div class="col-5  p-2" style="background-color: #fff">
                            <label for="inputPassword5" class="form-label">Price</label>
                            <input type="number" name="pprice"  class="form-control" aria-describedby="passwordHelpBlock" required>
                            <div id="passwordHelpBlock" class="form-text">
                              Enter the item price in peso.

                              
                               
                            </div>

                              <br>
                            <label for="inputPassword5" class="form-label">Image</label>
                             
                                <input type="file" class="form-control" id="customFile" name="pimage" value="" />
                                    <br>
                                    <br>
                                    <br><input type=submit value='Insert' name="submit2" style='font-size:15px;' class="btn btn-success" required>
                        </div>
                        </form>
                        <?php 
                            if(isset($_POST['submit2'])){
                                $pnm = $_POST['names'];
                                $pdtls = $_POST['details'];
                                $pprcs = $_POST['pprice'];
                                $img = "images/".$_FILES['pimage']['name'];
                                move_uploaded_file($_FILES['pimage']['tmp_name'], $img);

                                $con = new mysqli("localhost", "root", "", "test_db");
                                mysqli_query($con,"INSERT into products (p_name,p_price,p_details,p_image) VALUES('$pnm','$pprcs','$pdtls','$img')") or die(mysqli_error($con));
                                echo '<br><div class="alert alert-success" role="alert" id="alert">
                                                        Product Uploaded Successfully!
                                                        </div>';
 
                            }
                        ?>
                        
                    </div>
                </div>
            </div>
        </div>


</body> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>