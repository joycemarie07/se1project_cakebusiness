<?php 


session_start();

include "db_conn.php";


if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="cssNav2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

<style>
    body{
    background-color:#f2f2f2;
}
     *{font-family: 'Helvetica', 'Arial', sans-serif;}
    a{
        text-decoration: none;
        color: #f2f2f2;
    }
    a:hover{
color: #fff;
    }
    .ht1{height: 400px;overflow: auto;}
    .ht2{height: 60px;}
    table{width: 100%;
    }
    .divbgs{
        background-color: #3b5073;
        color: #fff;
        font-weight: normal;
        height: 100vh;
        overflow: auto;
    }
       .ht{
        height: 100vh;
        overflow: scroll;
    }
 .itemss:hover {
 box-shadow: 0 0 0 1px #d0d0d0;
    
}
.centerimg {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 70%;
  border-radius: 5px;
  ;
}
.ablk{
    color: black;
    font-size: 25px;

}

th, td {
    font-family: 'Helvetica', 'Arial', sans-serif;
  padding: 10px;
  font-size: 14px;

}

.hhf{height: 95vh;
        overflow: auto;}
</style>
</head>
<body>

         <!--NAV BAR-->
<?php 
include "nav.php";
?>

<!--CONTENTS-->
         <div class="container-fluid"> 
            
            <div class="row ">
                    <!--Left side-->
                <!-- <div class="col-lg-2 col-md-1 col-sm-1 divbgs"> <br><br><br> 
                        <div class="row itemss p-2">
                           <h6> <a href="product.php?messege"><i class="fa fa-list" ></i> <span id="fadeshow1">Product list</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6 ><a href="productAdd.php"><i class="fa fa-birthday-cake"></i> <span id="fadeshow1">Add Product</span></a></h6>
                        </div>
                     
                        <div class="row itemss p-3">
                           <h6> <a href="home.php?status"><i class="fa fa-arrow-circle-left"></i> <span id="fadeshow1">Back</span></a></h6>
                        </div>
                        
                  </div> -->
                    <!--Right side-->
                <div class="col-12 hhf ht"> 
                    <br><br><br>

                    <div class="row p-2  border-bottom">
                        <h2 style="color:#dc8ea0;font-weight:bold"><i class="fa fa-list" class="d-inline" ></i> Product list</h2>
                      
                    </div>
                    <div class="row pt-4 ps-4">
                         
                    </div>
                        <div class="row p-4">
                              <div class="col-12 rounded-top" style="background-color:#dc8ea0;height: 40px;" >
                                    <p style="font-size:15px;color:#fff;margin: 10px  ;" >Product Data</p>
                                    
                              </div>
                            <div class="col-12 " style="background-color: #fff;">
                                
                               <script>
                                    function myFunction() {
                                    var r = confirm("OK to delete?");
                                    if (r == false) {
                                       return false;
                                    } 

                                    }
                                </script>
                              <?php
                                $mysqli = new mysqli("localhost", "root", "", "test_db");
                                $sql = "SELECT * FROM products ORDER BY `p_id` DESC";

                                if($result = $mysqli->query($sql)){


                                        if($result->num_rows > 0){   

                             echo "<table class=' ' style='background-color:#fff'>";
                              echo "<thead>";
                                echo "<tr>";
                                  echo "<th scope='col'>#</th>";
                                  echo "<th scope='col'>Name</th>";
                                  echo "<th scope='col'>Price</th>";
                                  echo "<th scope='col'>Details</th>";
                                 
                                echo "</tr>";
                              echo "</thead>";

                                            while($rowss = $result->fetch_array())
                                            {
                              echo "<tbody>";
                                echo "<tr>";
                                  echo "<th scope='row'>" . $rowss['p_id'] . "</th>";
                                 echo " <td>" . $rowss['p_name'] . "</td>";
                                  echo "<td>" . $rowss['p_price'] . "</td>";
                                  echo "<td>" . $rowss['p_details'] . "</td>";
                                echo "</tr>";
                              echo "</tbody>";
                               }
                            echo "</table>";
                              }
                                        
                                else
                                {
                                    echo "No Current Items.";
                                }

                                }

                            ?>

                                <!-- NOTIF-->
                                        <script type="text/javascript">
                                            setTimeout(function(){
                                                document.getElementById("alert").style.display ="none";
                                            },3000);    
                                        </script>
                                 <?php if( $_GET['messege'] == 'success'):
                                            echo '<div class="alert alert-success" role="alert" id="alert">
                                                        Update Successfully!
                                                        </div>';
                                        endif; ?>

                                        <?php if( $_GET['messege'] == 'failed'):
                                            echo '<div class="alert alert-danger" role="alert"  id="alert">
                                                       Error!
                                                        </div>';
                                        endif; ?>

                            </div>

                        </div>
                  </div>
            </div>
        </div>
       



</body> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>