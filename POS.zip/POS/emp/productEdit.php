<?php 
session_start();
include "db_conn.php";
if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>

<?php 
// UPDATE PROFILE
if (isset($_POST['btnUpdate'])) {
    $id = $_POST['id'];
    $pname = $_POST['pname'];
    $pprice = $_POST['pprice'];
    $pdetails = $_POST['pdetails'];
 
   
   mysqli_query($conn,"UPDATE products SET p_name='$pname',p_price='$pprice',p_details='$pdetails' WHERE p_id='$id'");
    header('location: product.php?messege=success');
}
    
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

<style type="text/css">
     body{
    background-color:#f2f2f2;
}
</style>
</head>
<body>

	
			 <!--MODAL SECTION-->

        <div class=" "  >
                  <div class="modal-dialog ">
                    <div class="modal-content">
                        <form action="#" method="post">
                      <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Product Details</h1>
                        <a href="product.php?messege" class="btn-close"></a>
                      </div>
                      <div class="modal-body ">
                        <div class="form-group">
                            <?php
                                $mysqli = new mysqli("localhost", "root", "", "test_db");
                                $sql = "SELECT * FROM products  where p_id='$_GET[id]' ";
                                if($result = $mysqli->query($sql)){
                                    if($result->num_rows > 0){
                                        while($rowss = $result->fetch_array())
                                            {
                                                ?>
                            <input type="hidden" name="id"  class="form-control" value="<?php echo $rowss['p_id'] ?>" >                   
                            <label>Name: </label>
                            <input type="text" name="pname" class="form-control" value="<?php echo $rowss['p_name'] ?>" >
                            <label>Price: </label>
                            <input type="text" name="pprice" class="form-control" value="<?php echo $rowss['p_price'] ?>" >
                            <label>Details: </label>
                            <textarea class="form-control" name="pdetails" aria-label="With textarea"><?php echo $rowss['p_details'] ?></textarea>
                            
                           
                           
                                <?php   }
                                        }   
                                else
                                {
                                    echo "No Records.";
                                }
                                }
                                    ?>
                        </div>
                            
                      </div>
                      <div class="modal-footer">
                         <a href="product.php?messege"class="btn btn-secondary" >Close</a>
                        <button type="submit" class="btn btn-primary" name="btnUpdate">Save changes</button>
                      </div>
                        </form>
                    </div>
                  </div>
                </div>
	
</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}

 ?>