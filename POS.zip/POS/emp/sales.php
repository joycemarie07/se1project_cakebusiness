<?php 


session_start();

include "db_conn.php";


if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="cssNav2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

<style>
    body{
    background-color:#f2f2f2;
}
     *{font-family: 'Helvetica', 'Arial', sans-serif;}
    a{
        text-decoration: none;
        color: #f2f2f2;
    }
    a:hover{
color: #fff;
    }
    .ht1{height: 400px;overflow: auto;}
    .ht2{height: 60px;}
    table{width: 100%;
    }
   .ht{
        height: 100vh;
        overflow: scroll;
    }
 .itemss:hover {
 box-shadow: 0 0 0 1px #d0d0d0;
    
}
.centerimg {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 70%;
  border-radius: 5px;
  ;
}
.ablk{
    color: black;
    font-size: 25px;

}
@media only screen and (max-width: 1100px) {
    #fadeshow1 {
        display: none;
    }
}
table {
    width: 100%;
}
th, td {
    font-family: 'Helvetica', 'Arial', sans-serif;
  padding: 10px;
  font-size: 12px;
    /*border: 1px solid red;*/

}

.hhf{height: 440px;
        overflow: auto;}
.hhf::-webkit-scrollbar {
  display: none;
}

.srch{
    border-radius: 10px;
    border: none;
    width: 400px;
 
}
.btnsrch{
    padding: 0px;
    border: none;
    background-color: Transparent;
    margin-left: -65px;
    font-size: 14px;
    color: #ccc;
}
.btnsrch:hover{
    color: black;
    transition: .5s ;
}
.fl{
    float:right;
   padding-right: 20px;
}
.f2{
    float:right;
   padding-left: 20px;
}


    .sort-link {
padding: 0 20px;
  display: inline-block;
  position: relative;
}

.sort-link:after {
  content: '';
  position: absolute;
  width: 100%;
  transform: scaleX(0);
  height: 2px;
  bottom: 0;
  left: 0;
  background-color: #dc8ea0;
  transform-origin: bottom right;
  transition: transform 0.25s ease-out;

}

.sort-link:hover:after {

  transform: scaleX(1);
  transform-origin: bottom left;
}
.border1{
    border: 2px solid red;
}
</style>
</head>
<body>

         <!--NAV BAR-->
<?php 
include "nav.php";
?>

<!--CONTENTS-->
         <div class="container-fluid"> 
            
            <div class="row ">

                    <!--100-->
                <div class="col-12  ht"> 
                    <br><br><br>
                <p style="float:right;color:#dc8ea0 ;"><?php date_default_timezone_set("Asia/Manila"); echo date("Y-m-d") . " " . date("h:i:sa");?></p>
                    <div class="row p-2  ">

                        <h2 style="color:#dc8ea0;font-weight:bold"> Sales Report </h2> 
                    </div>
                        <div class="row p-4 hhf ">
                           <div class="col-12 p-2">
                               <a href="sales.php?search=latest&messege=" class="sort-link" style="color:black;">Latest</a>
                               <a href="sales.php?search=today&messege=" class="sort-link" style="color:black;">Today</a>
                               <a href="" class="sort-link" style="color:black;"></a>


                                <a href="printall.php" class="btn btn-secondary btn-md d-inline fl" disabled><i class='fa fa-print'> Print</i></a>
                           </div>
                              <div class="col-12 rounded-top p-3 d-inline " style="background-color:#dc8ea0;height: 60px;" >
                                <p class="d-inline" style="font-size:20px;color:#fff;margin: 10px  ;">Order list</p>
                                  <div class="d-inline fl">
                                       <form action="" method="get">
                                        
                                        <input class="d-inline srch p-1 " type="text" name="search">
                                        <input class="d-inline btnsrch "type="submit" name="messege" value="Search" >
                                   </form>
                                  </div>
                                    
                              </div>

                            <div class="col-12 " style="background-color: #fff;">
                                
                                <script type="text/javascript">
                            function ConfirmDelete()
                            {

                              return confirm("Are you sure you want to delete?");
                            }
                            </script>
                              <?php

                                if( empty($_GET['messege']) ):
                                         $mysqli = new mysqli("localhost", "root", "", "test_db");
                                        $sql = "SELECT * FROM sales";
   
                                        endif; 

                                if( $_GET['search'] == 'latest'):
                                        $srch= $_GET['search'];
                                         $mysqli = new mysqli("localhost", "root", "", "test_db");
                                        $sql = "SELECT * FROM sales ORDER BY `salesId` DESC";
                                        
                                        endif; 

                                if( $_GET['search'] == 'today' ):
                                    $date = date("Y-m-d");
                                        $srch= $_GET['search'];
                                         $mysqli = new mysqli("localhost", "root", "", "test_db");
                                        $sql = "SELECT * FROM sales WHERE odate LIKE '$date%' ";
   
                                        endif; 
                                

                                 if( $_GET['messege'] == 'Search'  ):
                                        $srch= $_GET['search'];
                                         $mysqli = new mysqli("localhost", "root", "", "test_db");
                                        $sql = "SELECT * FROM sales WHERE salesId LIKE'%$srch%' OR total_qty LIKE'%$srch%' OR cash LIKE'%$srch%' OR pchange LIKE'%$srch%' OR odate LIKE'%$srch%'";
   
                                        endif; 


                                               
                                if($result = $mysqli->query($sql)){


                                        if($result->num_rows > 0){   

                             echo "<table class='table ' style='background-color:#fff'>";
                              echo "<thead>";
                                echo "<tr>";
                                  echo "<th scope='col'>#</th>";
                                  echo "<th scope='col'>Quantity</th>";
                                  echo "<th scope='col'>Total Price</th>";
                                  echo "<th scope='col'>Cash</th>";
                                  echo "<th scope='col'>Change</th>";
                                  echo "<th scope='col'>Date | Time</th>";
                                  echo "<th scope='col'>Actions</th>";
                                echo "</tr>";
                              echo "</thead>";

                                            while($rowss = $result->fetch_array())
                                            {
                              echo "<tbody>";
                                echo "<tr>";
                                  echo "<th scope='row'>" . $rowss['salesId'] . "</th>";
                                 echo " <td>" . $rowss['total_qty'] . "</td>";
                                  echo "<td>" . $rowss['total_price'] . "</td>";
                                  echo "<td>" . $rowss['cash'] . "</td>";
                                  echo "<td>" . $rowss['pchange'] . "</td>";
                                  echo "<td>" . $rowss['odate'] . "</td>";
                                  echo "<td>
                                            <!-- Call to action buttons -->
                                            
                                                ";
                                                ?> 
                                                <li class='list-inline-item'>
                                                    <script type="text/javascript">
                                                        const myModal = document.getElementById('myModal')
                                                        const myInput = document.getElementById('myInput')

                                                        myModal.addEventListener('shown.bs.modal', () => {
                                                          myInput.focus()
                                                        })
                                                    </script>

                                                    <a href="salesEdit.php?id=<?php echo $rowss['salesId'] ?>" class="btn btn-success btn-sm rounded-0"  ><i class='fa fa-edit' ></i></a>

                                                <?php
                                                echo"
                                                <a href='printr1.php?salesId=".$rowss['salesId']."' class='btn btn-secondary btn-sm rounded-0'  data-placement='top''><i class='fa fa-print'></i></a>
                                                    <a href='function/deleteOL.php?salesId=".$rowss['salesId']."' class='btn btn-danger btn-sm rounded-0'  data-placement='top'  onclick='ConfirmDelete()'><i class='fa fa-trash'></i></a>
                                                    
                                    </td>";
                                echo "</tr>";
                              echo "</tbody>";
                               }
                            echo "</table>";
                              }
                                        
                                else
                                {
                                    echo "No Data.";
                                }

                                }

                            ?>

                                <!-- NOTIF-->
                                 <?php if( $_GET['messege'] == 'success'):
                                            echo '<div class="alert alert-success" role="alert">
                                                        Update Successfully!
                                                        </div>';
                                        endif; ?>

                                        <?php if( $_GET['messege'] == 'failed'):
                                            echo '<div class="alert alert-danger" role="alert">
                                                       Error!
                                                        </div>';
                                        endif; ?>

                            </div>

                        </div>
                  </div>
            </div>
        </div>
       



</body> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>