<?php 
session_start();
include "db_conn.php";
if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>

<?php 
// UPDATE PROFILE
if (isset($_POST['btnUpdate'])) {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
   
   mysqli_query($conn,"UPDATE users SET fname='$fname',mname='$mname',lname='$lname',address='$address',contact='$contact',email='$email' WHERE id='$id'");
    header('location: account.php?messege=success');
}
    
?>

 <!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

 <link rel="stylesheet" href="cssNav2.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

<style>


 *{font-family: 'Helvetica', 'Arial', sans-serif;}
    body{
        background-color: #f2f2f2;
    }
    a{
        text-decoration: none;
        color: #fff;
    }
    
    a:hover{
color: #fff;
    }
    .selected1 {
        text-decoration: none;
        color: #dc8ea0;
         font-size: 14px;
    }
    .selected1:hover {
      
        color: #dc8ea0;
    }
    .divbgs{

        background-color: #efcad2;
        color: #dc8ea0;
        font-weight: normal;
        height: 100vh;
        overflow: auto;
    }
    .itemss{
        background-color:#fff ;
        border: 1px solid #fff;
        border-radius: 10px;
        margin: 5px;

    }
 .itemss:hover {
/* box-shadow: 0 0 0 0px #dc8ea0;*/
 transition: .5s;
 background-color: #f8e8ec;
    
}
.centerimg {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 70%;
  border-radius: 5px;
  ;
}
.ablk{
    color: #f8e8ec;
    font-size: 25px;

}
.ablk:hover {
    color: #dc8ea0;
 transition: .5s;
}
@media only screen and (max-width: 1100px) {
    #fadeshow1 {
        display: none;
    }
}
th, td {
    font-family: 'Helvetica', 'Arial', sans-serif;
  padding: 10px;
   font-size: 14px;
}

h6{
    margin: 0px;
    padding: 0px;
}
</style>
</head>
<body>

         <!--NAV BAR-->
<?php 
include "nav.php";
?>  

         <!--CONTENTS-->
         <div class="container-fluid"> 
            
            <div class="row ">
                    <!--Left side-->
                <div class="col-lg-2 col-md-1 col-sm-1 divbgs"> <br><br><br> 
                        <div class="row itemss p-2 selected1">
                           <h6><a href="account.php" class="selected1" ><i class="fas fa-user-alt" ></i> <span id="fadeshow1">My Account</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6><a href="addAcount.php?status=" class="selected1"><i class="fas fa-user-plus"></i> <span id="fadeshow1">Add Account</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6><a href="acclist.php" class="selected1"><i class="fas fa-users"></i> <span id="fadeshow1">Employee List</span></a></h6>
                        </div>
                        <div class="row itemss p-2">
                           <h6> <a href="home.php?status" class="selected1"><i class="fa fa-arrow-circle-left"></i> <span id="fadeshow1">Back</span></a></h6>
                        </div>
                        
                  </div>
                    <!--Right side-->
                <div class="col-10"> 
                    <br>
                    <br>
                    <br>

                    <div class="row p-2  border-bottom">
                        <h2 style="color:#dc8ea0;font-weight:bold"><i class="fas fa-user-alt"></i> Account Managemant</h2>
                    </div>

                        <div class="row p-4 ">
                             <div class="col-12 rounded-top" style="background-color:#dc8ea0;height: 40px;" >
                                    <p style="font-size:15px;color:#fff;margin: 10px  ;">My Profile</p>
                              </div>
                            <div class="col-5  p-3" style="background-color:#fff;"><br><br>
                                <img src="images/user1.jpg" class="centerimg" >
                            </div> 
                            <div class="col-7  p-3" style="background-color:#fff;"><br> 
                                <div class="row">
                                    <div class="col-8"></div>
                                   
                                    <div class="col-4">
                                         <!-- EDIT MODAL -->
                                         <script type="text/javascript">
                                            const myModal = document.getElementById('myModal')
                                            const myInput = document.getElementById('myInput')

                                            myModal.addEventListener('shown.bs.modal', () => {
                                              myInput.focus()
                                            })
                                        </script>
                                        <button type="button" class="btn btn-sm" data-bs-toggle="modal" data-bs-target="#editModal">
                                         <i class="fas fa-edit ablk"></i>
                                        </button>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <?php
                                            $mysqli = new mysqli("localhost", "root", "", "test_db");
                                            $sql = "SELECT * FROM users WHERE id = '$_SESSION[id]'";

                                            if($result = $mysqli->query($sql)){


                                                    if($result->num_rows > 0){
                                                         while($rowss = $result->fetch_array())
                                            {
                                                             echo "<table> ";
                                                               echo "<tr>" ;
                                                                    echo "<td>Fullname:</td>";
                                                                    echo "<td colspan='2'>" . $rowss['fname'] ." ".$rowss['mname']. " ".$rowss['lname'] ."</td>";
                                                                echo "</tr>";
                                                                echo "<tr>";
                                                                    echo "<td>Address:</td>";
                                                                    echo "<td>" . $rowss['address'] . "</td>";
                                                                echo "</tr>";
                                                                echo "<tr>";
                                                                    echo "<td>Contact Number:</td>";
                                                                    echo "<td>" . $rowss['contact'] . "</td>";
                                                                echo "</tr>";
                                                                echo "<tr>";
                                                                    echo "<td>Email Address:</td>";
                                                                    echo "<td>" . $rowss['email'] . "</td>";
                                                                echo "</tr>";
                                                                echo "<tr>";
                                                                    echo "<td>Username:</td>";
                                                                    echo "<td>" . $rowss['user_name'] . "</td>";
                                                                echo "</tr>";
                                                                echo "<tr>";
                                                                    echo "<td>Password:</td>";
                                                                    echo "<td> xxxxx </td>";
                                                                echo "</tr>";
                                                            echo "</table><br>";
                                                            }
                                        }
                                        
                                else
                                {
                                    echo "No selected item/s yet.";
                                }

                                }
                                    ?>
                                    </div>
                                </div>
                                    
                            </div> 
                        </div>

                 <!-- Modal -->
                <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog ">
                    <div class="modal-content">
                        <form action="#" method="post">
                      <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Profile</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body ">
                        <div class="form-group">
                            <?php
                                $mysqli = new mysqli("localhost", "root", "", "test_db");
                                $sql = "SELECT * FROM users WHERE id = '$_SESSION[id]'";
                                if($result = $mysqli->query($sql)){
                                    if($result->num_rows > 0){
                                        while($rowss = $result->fetch_array())
                                            {
                                                ?>
                            <input type="hidden" name="id"  class="form-control" value="<?php echo $rowss['id'] ?>" >                   
                            <label>First Name: </label>
                            <input type="text" name="fname" class="form-control" value="<?php echo $rowss['fname'] ?>" >
                            <label>Middle Name: </label>
                            <input type="text" name="mname" class="form-control" value="<?php echo $rowss['mname'] ?>" >
                            <label>Last Name: </label>
                            <input type="text" name="lname" class="form-control" value="<?php echo $rowss['lname'] ?>" >
                            <label>Address: </label>
                            <input type="text" name="address" class="form-control" value="<?php echo $rowss['address'] ?>" >
                            <label>Contact: </label>
                            <input type="text" name="contact" class="form-control" value="<?php echo $rowss['contact'] ?>" >
                            <label>Email: </label>
                            <input type="text" name="email" class="form-control" value="<?php echo $rowss['email'] ?>" >
                           
                                <?php   }
                                        }   
                                else
                                {
                                    echo "No Records.";
                                }
                                }
                                    ?>
                        </div>
                            
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="btnUpdate">Save changes</button>
                      </div>
                        </form>
                    </div>
                  </div>
                </div>



                  </div>
            </div>
        </div>
       
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}

 ?>